function f() {
  var t = document.getElementById("input").value;
  document.getElementById("outputtext").innerHTML = "User 1: " + t;


}
